set -e

python regression.py
python run.py
